﻿namespace TweetAPI.Models
{
    public class ForgetPasswordUser
    {
        public string LoginID { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}
