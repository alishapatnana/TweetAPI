﻿namespace TweetAPI.Models
{
    public class LoginUser
    {
        public string LoginID { get; set; }
        public string Password { get; set; }
    }
}
