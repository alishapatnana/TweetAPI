﻿namespace TweetAPI.RabbitQueue
{
    public class Queue
    {
        public static string Processing { get; } = "TweetApp";
    }
}
